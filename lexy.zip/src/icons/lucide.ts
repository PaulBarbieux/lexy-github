import {  Menu, Search, User } from 'lucide-angular';

export const lucideIcons = {
  Search,
  User,
  Menu
};

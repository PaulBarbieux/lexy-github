export const queryKeys = {
  SEARCH: 'SEARCH',

};

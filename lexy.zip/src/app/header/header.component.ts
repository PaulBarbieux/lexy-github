import { Component } from '@angular/core';
import { HlmButtonDirective } from '@spartan-ng/ui-button-helm';
import { lucideIcons } from '~/icons/lucide';
import { LucideAngularModule } from 'lucide-angular';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [HlmButtonDirective, LucideAngularModule],
  template: `
    <section class="p-4">
      <div class="flex">
        <div class="grow">
          <img src="./img/logo-lexy.png" class="w-1/2" />
          <div>Le guide de Vivalis vers les services social-santé</div>
        </div>
        <div class="flex space-x-2">
          <button hlmBtn size="icon" class="rounded-full">
            <lucide-angular [img]="icons.Search" />
          </button>
          <button hlmBtn size="icon" variant="ghost" class="rounded-full">
            <lucide-angular [img]="icons.Menu" />
          </button>
        </div>
      </div>
    </section>
  `,
})
export class HeaderComponent {
  readonly icons = lucideIcons;
}

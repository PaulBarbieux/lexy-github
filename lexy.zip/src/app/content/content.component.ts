import { Component } from '@angular/core';

@Component({
  selector: 'app-content',
  standalone: true,
  imports: [],
  template: `
    <section>
      content works!
</section>
  `,
})
export class ContentComponent {

}

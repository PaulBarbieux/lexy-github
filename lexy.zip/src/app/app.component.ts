import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';

import { AppSignalStore } from './app.store';
import { HeaderComponent } from "./header/header.component";
import { BannerComponent } from "./banner/banner.component";
import { ContentComponent } from "./content/content.component";
import { FooterComponent } from "./footer/footer.component";

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, RouterOutlet, HeaderComponent, BannerComponent, ContentComponent, FooterComponent],
  selector: 'app-root',
  standalone: true,
  template: `
    <main class="bg-background">
      <app-header />
      <app-banner />
      <app-content />
      <app-footer />
    </main>

    <router-outlet></router-outlet>
  `,
})
export class AppComponent {
  readonly store = inject(AppSignalStore);
}

import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [],
  template: ` <section>footer works!</section> `,
})
export class FooterComponent {}

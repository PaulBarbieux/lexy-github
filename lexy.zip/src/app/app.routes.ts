import { lucideIcons } from '../icons/lucide';
import { AppComponent } from './app.component';

export const appName = 'My Angular App';

export const mainRoutes = [
  {
    
    component: AppComponent,
    icon: lucideIcons.User,
    label: 'home',
    path: 'home',
    title: `Home | ${appName}`,
    
  },
];

export const routes = [...mainRoutes];

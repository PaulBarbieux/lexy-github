import { Component } from '@angular/core';

@Component({
  selector: 'app-banner',
  standalone: true,
  imports: [],
  template: ` <section class="h-1/4">
    <img src="./img/banner.jpg" alt="Grand-Place de Bruxelles" class="object-cover w-full" />
  </section> `,
})
export class BannerComponent {}

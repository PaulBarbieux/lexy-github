export * from './hlm-avatar-fallback.directive';

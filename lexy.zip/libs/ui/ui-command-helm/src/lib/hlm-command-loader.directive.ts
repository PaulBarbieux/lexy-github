import { Directive } from '@angular/core';

@Directive({
	selector: '[hlmCmdLoader]',
	standalone: true,
})
export class HlmCommandLoaderDirective {}

import { HlmSliderInputDirective } from './lib/hlm-slider-input.directive';
import { HlmSliderThumbDirective } from './lib/hlm-slider-thumb.directive';
import { HlmSliderTrackComponent } from './lib/hlm-slider-track.component';
import { HlmSliderComponent } from './lib/hlm-slider.component';

export const HlmSliderImports = [
	HlmSliderComponent,
	HlmSliderTrackComponent,
	HlmSliderInputDirective,
	HlmSliderThumbDirective,
] as const;
